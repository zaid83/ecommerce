<!DOCTYPE html>
 <html>
     <head>
     
     <meta charset="utf-8">
         
         <meta name="viewport" content="">
         <link rel="stylesheet" type="text/css" href="panier_1.css">
         <link href="https://fonts.googleapis.com/css?family=Merienda" rel="stylesheet">
         <link href="https://fonts.googleapis.com/css?family=Cinzel|Noticia+Text" rel="stylesheet"> 
          
     
</head>


<body>
        
        
         <div class="carrefond">
         <p class="produit">Produit</p>
         <p class="provenance">Provenance</p>
         <p class="quantite">Quantité</p>
         <p class="prix">Prix</p>
         <div class="carrefond2">
         <img src="serra_da_estrelo1.png" alt="fromage" class="fromage">
         <p class="nomproduit">Serra Da Estrelo</p>
         <p class="enstock">En stock</p>
         <p class="paysprovenance">Portugal</p> 
         <p class="quantiteaffiche">500g</p>
         <p class="prixaffiche">14,50€</p>
                    </div>
       <div > 
    <a href="#" ><img src="bouton.png" alt="bouton" class="bouton"></a>
    </div> 
                    </div>
    
     
     </body>

</html>